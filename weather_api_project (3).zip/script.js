async function getWeather() {
  const city = document.getElementById('cityInput').value;
  const apiKey = 'YOUR_API_KEY'; // Replace with your actual OpenWeatherMap API key
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`;

  const weatherResult = document.getElementById('weatherResult');
  weatherResult.innerHTML = 'Loading...';

  try {
    const response = await fetch(url);
    if (!response.ok) {
      throw new Error('City not found');
    }

    const data = await response.json();
    const temp = data.main.temp;
    const desc = data.weather[0].description;

    weatherResult.innerHTML = `
      <strong>${data.name}</strong><br>
      Temperature: ${temp}°C<br>
      Condition: ${desc}
    `;
  } catch (error) {
    weatherResult.innerHTML = `Error: ${error.message}`;
  }
}
